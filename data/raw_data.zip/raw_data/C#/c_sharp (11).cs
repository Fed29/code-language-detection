using System.Reflection;

[assembly: AssemblyTitle("Microsoft.Bot.Builder.Integration.AspNet.WebApi.Tests")]
[assembly: AssemblyDescription("Test suite for Microsoft.Bot.Builder.Integration.AspNet.WebApi.")]

#if DEBUG
[assembly: AssemblyConfiguration("Debug")]
#else
[assembly: AssemblyConfiguration("Release")]
#endif

[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("Microsoft Bot Builder SDK")]
[assembly: AssemblyCopyright("© Microsoft Corporation. All rights reserved.")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
