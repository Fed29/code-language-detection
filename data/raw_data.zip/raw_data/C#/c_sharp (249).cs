﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Connector.Tests;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Schema;
using Microsoft.Rest;
using Xunit;

namespace Connector.Tests
{
    public class OAuthConnectorTests : BaseTest
    {
        private ConnectorClient mockConnectorClient = new ConnectorClient(new Uri("https://localhost"));

        [Fact]
        public void OAuthClient_ShouldNotThrowOnHttpUrl()
        {
            var client = new OAuthClient(mockConnectorClient, "http://localhost");
            Assert.NotNull(client);
        }

        [Fact]
        public void OAuthClient_ShouldThrowOnNullClient()
        {
            Assert.Throws<ArgumentNullException>(() => new OAuthClient(null, "https://localhost"));
        }

        [Fact]
        public async Task GetUserToken_ShouldThrowOnEmptyUserId()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.GetUserTokenAsync(string.Empty, "mockConnection", string.Empty));
        }

        [Fact]
        public async Task GetUserToken_ShouldThrowOnEmptyConnectionName()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.GetUserTokenAsync("userid", string.Empty, string.Empty));
        }

        [Fact]
        public async Task GetUserToken_ShouldReturnTokenWithNoMagicCode()
        {
            await UseOAuthClientFor(async client =>
             {
                 var token = await client.GetUserTokenAsync("default-user", "mygithubconnection", string.Empty);
                 Assert.NotNull(token);
                 Assert.False(string.IsNullOrEmpty(token.Token));
             });
        }

        [Fact]
        public async Task GetUserToken_ShouldReturnNullOnInvalidConnectionstring()
        {
            await UseOAuthClientFor(async client =>
             {
                 var token = await client.GetUserTokenAsync("default-user", "mygithubconnection1", string.Empty);
                 Assert.Null(token);
             });
        }

        // [Fact] - Disabled due to bug in service
        //public async Task GetSignInLinkAsync_ShouldReturnValidUrl()
        //{
        //    var activity = new Activity()
        //    {
        //        Id = "myid",
        //        From = new ChannelAccount() { Id = "fromId" },
        //        ServiceUrl = "https://localhost"
        //    };
        //    await UseOAuthClientFor(async client =>
        //     {
        //         var uri = await client.GetSignInLinkAsync(activity, "mygithubconnection");
        //         Assert.False(string.IsNullOrEmpty(uri));
        //         Uri uriResult;
        //         Assert.True(Uri.TryCreate(uri, UriKind.Absolute, out uriResult) && uriResult.Scheme == Uri.UriSchemeHttps);
        //     });
        //}

        [Fact]
        public async Task SignOutUser_ShouldThrowOnEmptyUserId()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.SignOutUserAsync(string.Empty, "mockConnection"));
        }

        [Fact]
        public async Task GetSigninLink_ShouldThrowOnNullState()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.GetSignInLinkAsync(null));
        }

        [Fact]
        public async Task GetTokenStatus_ShouldThrowOnNullUserId()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.GetTokenStatusAsync(null));
        }

        [Fact]
        public async Task GetAadTokensAsync_ShouldThrowOnNullUserId()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.GetAadTokensAsync(null, "connection", new string[] { "hello" }));
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.GetAadTokensAsync("", "connection", new string[] { "hello" }));
        }

        [Fact]
        public async Task GetAadTokensAsync_ShouldThrowOnNullConncetionName()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.GetAadTokensAsync("user", null, new string[] { "hello" }));
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.GetAadTokensAsync("user", "", new string[] { "hello" }));
        }

        [Fact]
        public async Task GetAadTokensAsync_ShouldThrowOnNullResourceUrls()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentNullException>(() => client.GetAadTokensAsync("user", "connection", null));
        }

        [Fact]
        public async Task GetAadTokensAsync_ShouldThrowOnNullResourceUrl()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentException>(() => client.GetAadTokensAsync("user", "connection", new string[] { null }));
            await Assert.ThrowsAsync<ArgumentException>(() => client.GetAadTokensAsync("user", "connection", new string[] { "" }));
        }

        [Fact]
        public async Task GetAadTokensAsync_ShouldThrowOnEmptyResourceUrls()
        {
            var client = new OAuthClient(mockConnectorClient, "https://localhost");
            await Assert.ThrowsAsync<ArgumentException>(() => client.GetAadTokensAsync("user", "connection", new string[] { }));
        }
    }
}
