{-# OPTIONS_GHC -F -pgmF tasty-discover -optF --tree-display #-}
