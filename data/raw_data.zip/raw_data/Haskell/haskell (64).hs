module Unison.Settings where

debugNoteLoc,debugNoteSummary :: Bool
debugNoteLoc = False
debugNoteSummary = False
