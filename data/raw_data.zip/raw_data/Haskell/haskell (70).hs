{-# LANGUAGE DeriveFoldable #-}
{-# LANGUAGE DeriveFunctor #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveTraversable #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE Rank2Types #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE UnicodeSyntax #-}
{-# LANGUAGE ViewPatterns #-}

module Unison.Term where

import Prelude hiding (and,or)
import qualified Control.Monad.Writer.Strict as Writer
import Data.Functor (void)
import           Data.Foldable (traverse_, toList)
import           Data.Int (Int64)
import           Data.List (foldl')
import           Data.Map (Map)
import qualified Data.Map as Map
import           Data.Set (Set, union)
import qualified Data.Set as Set
import           Data.Text (Text)
import qualified Data.Text as Text
import           Data.Vector (Vector)
import qualified Data.Vector as Vector
import           Data.Word (Word64)
import           GHC.Generics
import           Prelude.Extras (Eq1(..), Show1(..))
import           Text.Show
import qualified Unison.ABT as ABT
import qualified Unison.Blank as B
import           Unison.Hash (Hash)
import qualified Unison.Hash as Hash
import           Unison.Hashable (Hashable1, accumulateToken)
import qualified Unison.Hashable as Hashable
import           Unison.PatternP (Pattern)
import qualified Unison.PatternP as Pattern
import           Unison.Reference (Reference(..))
import qualified Unison.Reference as Reference
import           Unison.Type (Type)
import qualified Unison.Type as Type
import           Unison.Var (Var)
import qualified Unison.Var as Var
import           Unsafe.Coerce

-- todo: add loc to MatchCase
data MatchCase loc a = MatchCase (Pattern loc) (Maybe a) a
  deriving (Show,Eq,Foldable,Functor,Generic,Generic1,Traversable)

-- | Base functor for terms in the Unison language
-- We need `typeVar` because the term and type variables may differ.
data F typeVar typeAnn patternAnn a
  = Int64 Int64
  | UInt64 Word64
  | Float Double
  | Boolean Bool
  | Text Text
  | Blank (B.Blank typeAnn)
  | Ref Reference
  -- First argument identifies the data type,
  -- second argument identifies the constructor
  | Constructor Reference Int
  | Request Reference Int
  | Handle a a
  | App a a
  | Ann a (Type.AnnotatedType typeVar typeAnn)
  | Vector (Vector a)
  | If a a a
  | And a a
  | Or a a
  | Lam a
  -- Note: let rec blocks have an outer ABT.Cycle which introduces as many
  -- variables as there are bindings
  | LetRec [a] a
  -- Note: first parameter is the binding, second is the expression which may refer
  -- to this let bound variable. Constructed as `Let b (abs v e)`
  | Let a a
  -- Pattern matching / eliminating data types, example:
  --  case x of
  --    Just n -> rhs1
  --    Nothing -> rhs2
  --
  -- translates to
  --
  --   Match x
  --     [ (Constructor 0 [Var], ABT.abs n rhs1)
  --     , (Constructor 1 [], rhs2) ]
  | Match a [MatchCase patternAnn a]
  deriving (Foldable,Functor,Generic,Generic1,Traversable)

-- | Like `Term v`, but with an annotation of type `a` at every level in the tree
type AnnotatedTerm v a = AnnotatedTerm2 v a a v a
-- | Allow type variables and term variables to differ
type AnnotatedTerm' vt v a = AnnotatedTerm2 vt a a v a
-- | Allow type variables, term variables, type annotations and term annotations
-- to all differ
type AnnotatedTerm2 vt at ap v a = ABT.Term (F vt at ap) v a

-- | Terms are represented as ABTs over the base functor F, with variables in `v`
type Term v = AnnotatedTerm v ()
-- | Terms with type variables in `vt`, and term variables in `v`
type Term' vt v = AnnotatedTerm' vt v ()

bindBuiltins :: forall v a b b2. Var v
             => [(v, AnnotatedTerm2 v b a v b2)]
             -> [(v, Reference)]
             -> AnnotatedTerm2 v b a v a
             -> AnnotatedTerm2 v b a v a
bindBuiltins termBuiltins typeBuiltins t =
   f . g $ t
   where
   f :: AnnotatedTerm2 v b a v a -> AnnotatedTerm2 v b a v a
   f = typeMap (Type.bindBuiltins typeBuiltins)
   g :: AnnotatedTerm2 v b a v a -> AnnotatedTerm2 v b a v a
   g = ABT.substsInheritAnnotation termBuiltins

typeDirectedResolve :: Var v
                    => ABT.Term (F vt b ap) v b -> ABT.Term (F vt b ap) v b
typeDirectedResolve t = fmap fst . ABT.visitPure f $ ABT.annotateBound t
  where f (ABT.Term _ (a, bound) (ABT.Var v)) | Set.notMember v bound =
          Just $ resolve (a, bound) a (Text.unpack $ Var.name v)
        f _ = Nothing

vmap :: Ord v2 => (v -> v2) -> AnnotatedTerm v a -> AnnotatedTerm v2 a
vmap f = ABT.vmap f . typeMap (ABT.vmap f)

vtmap :: Ord vt2 => (vt -> vt2) -> AnnotatedTerm' vt v a -> AnnotatedTerm' vt2 v a
vtmap f = typeMap (ABT.vmap f)

typeMap :: Ord vt2 => (Type.AnnotatedType vt at -> Type.AnnotatedType vt2 at2)
                   -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt2 at2 ap v a
typeMap f t = go t where
  go (ABT.Term fvs a t) = ABT.Term fvs a $ case t of
    ABT.Abs v t -> ABT.Abs v (go t)
    ABT.Var v -> ABT.Var v
    ABT.Cycle t -> ABT.Cycle (go t)
    ABT.Tm (Ann e t) -> ABT.Tm (Ann (go e) (f t))
    -- Safe since `Ann` is only ctor that has embedded `Type v` arg
    -- otherwise we'd have to manually match on every non-`Ann` ctor
    ABT.Tm ts -> unsafeCoerce $ ABT.Tm (fmap go ts)

unannotate :: ∀ vt at ap v a . Ord v => AnnotatedTerm2 vt at ap v a -> Term' vt v
unannotate t = go t where
  go :: AnnotatedTerm2 vt at ap v a -> Term' vt v
  go (ABT.out -> ABT.Abs v body) = ABT.abs v (go body)
  go (ABT.out -> ABT.Cycle body) = ABT.cycle (go body)
  go (ABT.Var' v) = ABT.var v
  go (ABT.Tm' f) =
    case go <$> f of
      Ann e t -> ABT.tm (Ann e (void t))
      Match scrutinee branches ->
        let unann (MatchCase pat guard body) = MatchCase (void pat) guard body
        in ABT.tm (Match scrutinee (unann <$> branches))
      f' -> ABT.tm (unsafeCoerce f')
  go _ = error "unpossible"

wrapV :: Ord v => AnnotatedTerm v a -> AnnotatedTerm (ABT.V v) a
wrapV = vmap ABT.Bound

freeVars :: AnnotatedTerm' vt v a -> Set v
freeVars = ABT.freeVars

freeTypeVars :: Ord vt => AnnotatedTerm' vt v a -> Set vt
freeTypeVars t = go t where
  go :: Ord vt => AnnotatedTerm' vt v a -> Set vt
  go (ABT.Term _ _ t) = case t of
    ABT.Abs _ t -> go t
    ABT.Var _ -> Set.empty
    ABT.Cycle t -> go t
    ABT.Tm (Ann e t) -> Type.freeVars t `union` go e
    ABT.Tm ts -> foldMap go ts

-- nicer pattern syntax

pattern Var' v <- ABT.Var' v
pattern Int64' n <- (ABT.out -> ABT.Tm (Int64 n))
pattern UInt64' n <- (ABT.out -> ABT.Tm (UInt64 n))
pattern Float' n <- (ABT.out -> ABT.Tm (Float n))
pattern Boolean' b <- (ABT.out -> ABT.Tm (Boolean b))
pattern Text' s <- (ABT.out -> ABT.Tm (Text s))
pattern Blank' b <- (ABT.out -> ABT.Tm (Blank b))
pattern Ref' r <- (ABT.out -> ABT.Tm (Ref r))
pattern Builtin' r <- (ABT.out -> ABT.Tm (Ref (Builtin r)))
pattern App' f x <- (ABT.out -> ABT.Tm (App f x))
pattern Match' scrutinee branches <- (ABT.out -> ABT.Tm (Match scrutinee branches))
pattern Constructor' ref n <- (ABT.out -> ABT.Tm (Constructor ref n))
pattern Request' ref n <- (ABT.out -> ABT.Tm (Request ref n))
pattern RequestOrCtor' ref n <- (unReqOrCtor -> Just (ref, n))
pattern If' cond t f <- (ABT.out -> ABT.Tm (If cond t f))
pattern And' x y <- (ABT.out -> ABT.Tm (And x y))
pattern Or' x y <- (ABT.out -> ABT.Tm (Or x y))
pattern Handle' h body <- (ABT.out -> ABT.Tm (Handle h body))
pattern Apps' f args <- (unApps -> Just (f, args))
pattern Ann' x t <- (ABT.out -> ABT.Tm (Ann x t))
pattern Vector' xs <- (ABT.out -> ABT.Tm (Vector xs))
pattern Lam' subst <- ABT.Tm' (Lam (ABT.Abs' subst))
pattern LamNamed' v body <- (ABT.out -> ABT.Tm (Lam (ABT.Term _ _ (ABT.Abs v body))))
pattern Let1' b subst <- (unLet1 -> Just (b, subst))
pattern Let1Named' v b e <- (ABT.Tm' (Let b (ABT.out -> ABT.Abs v e)))
pattern Lets' bs e <- (unLet -> Just (bs, e))
pattern LetRecNamed' bs e <- (unLetRecNamed -> Just (bs,e))
pattern LetRec' subst <- (unLetRec -> Just subst)
pattern LetRecNamedAnnotated' ann bs e <- (unLetRecNamedAnnotated -> Just (ann, bs,e))

fresh :: Var v => Term v -> v -> v
fresh = ABT.fresh

-- some smart constructors

var :: a -> v -> AnnotatedTerm2 vt at ap v a
var = ABT.annotatedVar

var' :: Var v => Text -> Term' vt v
var' = var() . ABT.v'

derived :: Ord v => a -> Hash -> AnnotatedTerm2 vt at ap v a
derived a = ref a . Reference.Derived

derived' :: Ord v => Text -> Maybe (Term' vt v)
derived' base58 = derived () <$> Hash.fromBase58 base58

ref :: Ord v => a -> Reference -> AnnotatedTerm2 vt at ap v a
ref a r = ABT.tm' a (Ref r)

builtin :: Ord v => a -> Text -> AnnotatedTerm2 vt at ap v a
builtin a n = ref a (Reference.Builtin n)

float :: Ord v => a -> Double -> AnnotatedTerm2 vt at ap v a
float a d = ABT.tm' a (Float d)

boolean :: Ord v => a -> Bool -> AnnotatedTerm2 vt at ap v a
boolean a b = ABT.tm' a (Boolean b)

int64 :: Ord v => a -> Int64 -> AnnotatedTerm2 vt at ap v a
int64 a d = ABT.tm' a (Int64 d)

uint64 :: Ord v => a -> Word64 -> AnnotatedTerm2 vt at ap v a
uint64 a d = ABT.tm' a (UInt64 d)

text :: Ord v => a -> Text -> AnnotatedTerm2 vt at ap v a
text a = ABT.tm' a . Text

unit :: Var v => a -> AnnotatedTerm v a
unit ann = constructor ann (Reference.Builtin "()") 0

-- delayed terms are just lambdas that take a single `()` arg
-- `force` calls the function
force :: Var v => a -> a -> AnnotatedTerm v a -> AnnotatedTerm v a
force a au e = app a e (unit au)

delay :: Var v => a -> AnnotatedTerm v a -> AnnotatedTerm v a
delay a e = lam a (Var.named "u") e

blank :: Ord v => a -> AnnotatedTerm2 vt at ap v a
blank a = ABT.tm' a (Blank B.Blank)

placeholder :: Ord v => a -> String -> AnnotatedTerm2 vt a ap v a
placeholder a s = ABT.tm' a . Blank $ B.Recorded (B.Placeholder a s)

resolve :: Ord v => at -> ab -> String -> AnnotatedTerm2 vt ab ap v at
resolve at ab s = ABT.tm' at . Blank $ B.Recorded (B.Resolve ab s)

constructor :: Ord v => a -> Reference -> Int -> AnnotatedTerm2 vt at ap v a
constructor a ref n = ABT.tm' a (Constructor ref n)

request :: Ord v => a -> Reference -> Int -> AnnotatedTerm2 vt at ap v a
request a ref n = ABT.tm' a (Request ref n)

-- todo: delete and rename app' to app
app_ :: Ord v => Term' vt v -> Term' vt v -> Term' vt v
app_ f arg = ABT.tm (App f arg)

app :: Ord v => a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a
app a f arg = ABT.tm' a (App f arg)

match :: Ord v => a -> AnnotatedTerm2 vt at a v a -> [MatchCase a (AnnotatedTerm2 vt at a v a)] -> AnnotatedTerm2 vt at a v a
match a scrutinee branches = ABT.tm' a (Match scrutinee branches)

handle :: Ord v => a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a
handle a h block = ABT.tm' a (Handle h block)

and :: Ord v => a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a
and a x y = ABT.tm' a (And x y)

or :: Ord v => a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a
or a x y = ABT.tm' a (Or x y)

vector :: Ord v => a -> [AnnotatedTerm2 vt at ap v a] -> AnnotatedTerm2 vt at ap v a
vector a es = vector' a (Vector.fromList es)

vector' :: Ord v => a -> Vector (AnnotatedTerm2 vt at ap v a) -> AnnotatedTerm2 vt at ap v a
vector' a es = ABT.tm' a (Vector es)

apps :: Ord v => AnnotatedTerm2 vt at ap v a -> [(a, AnnotatedTerm2 vt at ap v a)] -> AnnotatedTerm2 vt at ap v a
apps f = foldl' (\f (a,t) -> app a f t) f

apps' :: (Ord v, Semigroup a)
      => AnnotatedTerm2 vt at ap v a -> [AnnotatedTerm2 vt at ap v a] -> AnnotatedTerm2 vt at ap v a
apps' f = foldl' (\f t -> app (ABT.annotation f <> ABT.annotation t) f t) f

iff :: Ord v => a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a
iff a cond t f = ABT.tm' a (If cond t f)

ann_ :: Ord v => Term' vt v -> Type vt -> Term' vt v
ann_ e t = ABT.tm (Ann e t)

ann :: Ord v
    => a
    -> AnnotatedTerm2 vt at ap v a
    -> Type.AnnotatedType vt at
    -> AnnotatedTerm2 vt at ap v a
ann a e t = ABT.tm' a (Ann e t)

-- arya: are we sure we want the two annotations to be the same?
lam :: Ord v => a -> v -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a
lam a v body = ABT.tm' a (Lam (ABT.abs' a v body))

lam' :: Ord v => a -> [v] -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a
lam' a vs body = foldr (lam a) body vs

lam'' :: Ord v => [(a,v)] -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a
lam'' vs body = foldr (uncurry lam) body vs

arity :: AnnotatedTerm2 vt at ap v a -> Int
arity (LamNamed' _ body) = 1 + arity body
arity (Ann' e _) = arity e
arity _ = 0

unLetRecNamedAnnotated :: AnnotatedTerm' vt v a -> Maybe (a, [((a, v), AnnotatedTerm' vt v a)], AnnotatedTerm' vt v a)
unLetRecNamedAnnotated (ABT.CycleA' ann avs (ABT.Tm' (LetRec bs e))) =
  Just (ann, avs `zip` bs, e)
unLetRecNamedAnnotated _ = Nothing

letRec :: Ord v => a -> [((a,v), AnnotatedTerm' vt v a)] -> AnnotatedTerm' vt v a -> AnnotatedTerm' vt v a
letRec _ [] e = e
letRec a bindings e = ABT.cycle' a (foldr (uncurry ABT.abs') z (map fst bindings))
  where
    z = ABT.tm' a (LetRec (map snd bindings) e)

-- | Smart constructor for let rec blocks. Each binding in the block may
-- reference any other binding in the block in its body (including itself),
-- and the output expression may also reference any binding in the block.
letRec_ :: Ord v => [(v, Term' vt v)] -> Term' vt v -> Term' vt v
letRec_ [] e = e
letRec_ bindings e = ABT.cycle (foldr ABT.abs z (map fst bindings))
  where
    z = ABT.tm (LetRec (map snd bindings) e)

-- | Smart constructor for let blocks. Each binding in the block may
-- reference only previous bindings in the block, not including itself.
-- The output expression may reference any binding in the block.
-- todo: delete me
let1_ :: Ord v => [(v,Term' vt v)] -> Term' vt v -> Term' vt v
let1_ bindings e = foldr f e bindings
  where
    f (v,b) body = ABT.tm (Let b (ABT.abs v body))

-- | annotations are applied to each nested Let expression
let1 :: Ord v => [((a, v), AnnotatedTerm2 vt at ap v a)] -> AnnotatedTerm2 vt at ap v a -> AnnotatedTerm2 vt at ap v a
let1 bindings e = foldr f e bindings
  where
    f ((ann,v),b) body = ABT.tm' ann (Let b (ABT.abs' ann v body))

let1' :: (Semigroup a, Ord v)
      => [(v, AnnotatedTerm2 vt at ap v a)]
      -> AnnotatedTerm2 vt at ap v a
      -> AnnotatedTerm2 vt at ap v a
let1' bindings e = foldr f e bindings
  where
    ann = ABT.annotation
    f (v,b) body = ABT.tm' a (Let b (ABT.abs' a v body)) where
      a = ann b <> ann body

-- let1' :: Var v => [(Text, Term' vt v)] -> Term' vt v -> Term' vt v
-- let1' bs e = let1 [(ABT.v' name, b) | (name,b) <- bs ] e

unLet1 :: Var v => AnnotatedTerm' vt v a -> Maybe (AnnotatedTerm' vt v a, ABT.Subst (F vt a a) v a)
unLet1 (ABT.Tm' (Let b (ABT.Abs' subst))) = Just (b, subst)
unLet1 _ = Nothing

-- | Satisfies `unLet (let' bs e) == Just (bs, e)`
unLet :: AnnotatedTerm' vt v a -> Maybe ([(v, AnnotatedTerm' vt v a)], AnnotatedTerm' vt v a)
unLet t = fixup (go t) where
  go (ABT.Tm' (Let b (ABT.out -> ABT.Abs v t))) =
    case go t of (env,t) -> ((v,b):env, t)
  go t = ([], t)
  fixup ([], _) = Nothing
  fixup bst = Just bst

-- | Satisfies `unLetRec (letRec bs e) == Just (bs, e)`
unLetRecNamed :: AnnotatedTerm2 vt at ap v a -> Maybe ([(v, AnnotatedTerm2 vt at ap v a)], AnnotatedTerm2 vt at ap v a)
unLetRecNamed (ABT.Cycle' vs (ABT.Tm' (LetRec bs e)))
  | length vs == length vs = Just (zip vs bs, e)
unLetRecNamed _ = Nothing

unLetRec :: (Monad m, Var v)
         => AnnotatedTerm2 vt at ap v a
         -> Maybe ((v -> m v) ->
                   m ([(v, AnnotatedTerm2 vt at ap v a)], AnnotatedTerm2 vt at ap v a))
unLetRec (unLetRecNamed -> Just (bs, e)) = Just $ \freshen -> do
  vs <- sequence [ freshen v | (v,_) <- bs ]
  let sub = ABT.substsInheritAnnotation (map fst bs `zip` map ABT.var vs)
  pure (vs `zip` [ sub b | (_,b) <- bs ], sub e)
unLetRec _ = Nothing

unApps :: AnnotatedTerm2 vt at ap v a -> Maybe (AnnotatedTerm2 vt at ap v a, [AnnotatedTerm2 vt at ap v a])
unApps t = case go t [] of [] -> Nothing; f:args -> Just (f,args)
  where
  go (App' i o) acc = go i (o:acc)
  go _ [] = []
  go fn args = fn:args

pattern LamsNamed' vs body <- (unLams' -> Just (vs, body))

unLams' :: AnnotatedTerm2 vt at ap v a -> Maybe ([v], AnnotatedTerm2 vt at ap v a)
unLams' (LamNamed' v body) = case unLams' body of
  Nothing -> Just ([v], body)
  Just (vs, body) -> Just (v:vs, body)
unLams' _ = Nothing

unReqOrCtor :: AnnotatedTerm2 vt at ap v a -> Maybe (Reference, Int)
unReqOrCtor (Constructor' r cid) = Just (r, cid)
unReqOrCtor (Request' r cid)     = Just (r, cid)
unReqOrCtor _                         = Nothing

dependencies' :: Ord v => AnnotatedTerm2 vt at ap v a -> Set Reference
dependencies' t = Set.fromList . Writer.execWriter $ ABT.visit' f t
  where f t@(Ref r) = Writer.tell [r] *> pure t
        f t = pure t

dependencies :: Ord v => AnnotatedTerm2 vt at ap v a -> Set Hash
dependencies e = Set.fromList [ h | Reference.Derived h <- Set.toList (dependencies' e) ]

referencedDataDeclarations :: Ord v => AnnotatedTerm2 vt at ap v a -> Set Reference
referencedDataDeclarations t = Set.fromList . Writer.execWriter $ ABT.visit' f t
  where f t@(Constructor r _) = Writer.tell [r] *> pure t
        f t@(Match _ cases) = traverse_ g cases *> pure t where
          g (MatchCase pat _ _) = Writer.tell (Set.toList (referencedDataDeclarationsP pat))
        f t = pure t

referencedDataDeclarationsP :: Pattern loc -> Set Reference
referencedDataDeclarationsP p = Set.fromList . Writer.execWriter $ go p where
  go (Pattern.As _ p) = go p
  go (Pattern.Constructor _ id _ args) = Writer.tell [id] *> traverse_ go args
  go (Pattern.EffectPure _ p) = go p
  go (Pattern.EffectBind _ _ _ args k) = traverse_ go args *> go k
  go _ = pure ()

referencedEffectDeclarations :: Ord v => AnnotatedTerm2 vt at ap v a -> Set Reference
referencedEffectDeclarations t = Set.fromList . Writer.execWriter $ ABT.visit' f t
  where f t@(Request r _) = Writer.tell [r] *> pure t
        f t@(Match _ cases) = traverse_ g cases *> pure t where
          g (MatchCase pat _ _) = Writer.tell (Set.toList (referencedEffectDeclarationsP pat))
          -- todo: does this traverse the guard and body of MatchCase?
        f t = pure t

referencedEffectDeclarationsP :: Pattern loc -> Set Reference
referencedEffectDeclarationsP p = Set.fromList . Writer.execWriter $ go p where
  go (Pattern.As _ p) = go p
  go (Pattern.Constructor _ _ _ args) = traverse_ go args
  go (Pattern.EffectPure _ p) = go p
  go (Pattern.EffectBind _ id _ args k) = Writer.tell [id] *> traverse_ go args *> go k
  go _ = pure ()

updateDependencies :: Ord v => Map Reference Reference -> Term v -> Term v
updateDependencies u tm = ABT.rebuildUp go tm where
  go (Ref r) = Ref (Map.findWithDefault r r u)
  go f = f

-- | If the outermost term is a function application,
-- perform substitution of the argument into the body
betaReduce :: Var v => Term v -> Term v
betaReduce (App' (Lam' f) arg) = ABT.bind f arg
betaReduce e = e

anf :: ∀ vt at v a . (Semigroup a, Var v)
    => AnnotatedTerm2 vt at a v a -> AnnotatedTerm2 vt at a v a
anf t = go t where
  ann = ABT.annotation
  isVar (Var' _) = True
  isVar _ = False
  isClosedLam t@(LamNamed' _ _) | Set.null (ABT.freeVars t) = True
  isClosedLam _ = False
  fixAp t f args =
    let
      args' = Map.fromList $ toVar =<< (args `zip` [0..])
      toVar (b, i) | isVar b   = []
                   | otherwise = [(i, ABT.fresh t (Var.named . Text.pack $ "arg" ++ show i))]
      argsANF = map toANF (args `zip` [0..])
      toANF (b,i) = maybe b (var (ann b)) $ Map.lookup i args'
      addLet (b,i) body = maybe body (\v -> let1' [(v,go b)] body) (Map.lookup i args')
    in foldr addLet (apps' f argsANF) (args `zip` [(0::Int)..])
  go :: AnnotatedTerm2 vt at a v a -> AnnotatedTerm2 vt at a v a
  go (Apps' f@(LamsNamed' vs body) args) | isClosedLam f = ap vs body args where
    ap vs body [] = lam' (ann f) vs body
    ap (v:vs) body (arg:args) = let1' [(v,arg)] $ ap vs body args
    ap [] _body _args = error "type error"
  go t@(Apps' f args)
    | isVar f = fixAp t f args
    | otherwise = let fv' = ABT.fresh t (Var.named "f")
                  in let1' [(fv', anf f)] (fixAp t (var (ann f) fv') args)
  go e@(Handle' h body)
    | isVar h = handle (ann e) h (go body)
    | otherwise = let h' = ABT.fresh e (Var.named "handler")
                  in let1' [(h', go h)] (handle (ann e) (var (ann h) h') (go body))
  go e@(If' cond t f)
    | isVar cond = iff (ann e) cond (go t) (go f)
    | otherwise = let cond' = ABT.fresh e (Var.named "cond")
                  in let1' [(cond', anf cond)] (iff (ann e) (var (ann cond) cond') t f)
  go e@(Match' scrutinee cases)
    | isVar scrutinee = match (ann e) scrutinee (fmap go <$> cases)
    | otherwise = let scrutinee' = ABT.fresh e (Var.named "scrutinee")
                  in let1' [(scrutinee', go scrutinee)] (match (ann e) (var (ann scrutinee) scrutinee') cases)
  go e@(And' x y)
    | isVar x = and (ann e) x (go y)
    | otherwise =
        let x' = ABT.fresh e (Var.named "argX")
        in let1' [(x', anf x)] (and (ann e) (var (ann x) x') (go y))
  go e@(Or' x y)
    | isVar x = or (ann e) x (go y)
    | otherwise =
        let x' = ABT.fresh e (Var.named "argX")
        in let1' [(x', go x)] (or (ann e) (var (ann x) x') (go y))
  go e@(ABT.Tm' f) = ABT.tm' (ann e) (go <$> f)
  go e@(ABT.Var' _) = e
  go e@(ABT.out -> ABT.Cycle body) = ABT.cycle' (ann e) (go body)
  go e@(ABT.out -> ABT.Abs v body) = ABT.abs' (ann e) v (go body)
  go e = e

instance Var v => Hashable1 (F v a p) where
  hash1 hashCycle hash e =
    let
      (tag, hashed, varint) = (Hashable.Tag, Hashable.Hashed, Hashable.UInt64 . fromIntegral)
    in case e of
      -- So long as `Reference.Derived` ctors are created using the same hashing
      -- function as is used here, this case ensures that references are 'transparent'
      -- wrt hash and hashing is unaffected by whether expressions are linked.
      -- So for example `x = 1 + 1` and `y = x` hash the same.
      Ref (Reference.Derived h) -> Hashable.fromBytes (Hash.toBytes h)
      -- Note: start each layer with leading `1` byte, to avoid collisions with
      -- types, which start each layer with leading `0`. See `Hashable1 Type.F`
      _ -> Hashable.accumulate $ tag 1 : case e of
        UInt64 i -> [tag 64, accumulateToken i]
        Int64 i -> [tag 65, accumulateToken i]
        Float n -> [tag 66, Hashable.Double n]
        Boolean b -> [tag 67, accumulateToken b]
        Text t -> [tag 68, accumulateToken t]
        Blank b -> tag 1 :
          case b of
            B.Blank -> [tag 0]
            B.Recorded (B.Placeholder _ s) -> [tag 1, Hashable.Text (Text.pack s)]
            B.Recorded (B.Resolve _ s)  -> [tag 2, Hashable.Text (Text.pack s)]
        Ref (Reference.Builtin name) -> [tag 2, accumulateToken name]
        Ref (Reference.Derived _) -> error "handled above, but GHC can't figure this out"
        App a a2 -> [tag 3, hashed (hash a), hashed (hash a2)]
        Ann a t -> [tag 4, hashed (hash a), hashed (ABT.hash t)]
        Vector as -> tag 5 : varint (Vector.length as) : map (hashed . hash) (Vector.toList as)
        Lam a -> [tag 6, hashed (hash a) ]
        -- note: we use `hashCycle` to ensure result is independent of let binding order
        LetRec as a -> case hashCycle as of
          (hs, hash) -> tag 7 : hashed (hash a) : map hashed hs
        -- here, order is significant, so don't use hashCycle
        Let b a -> [tag 8, hashed $ hash b, hashed $ hash a]
        If b t f -> [tag 9, hashed $ hash b, hashed $ hash t, hashed $ hash f]
        Request r n -> [tag 10, accumulateToken r, varint n]
        Constructor r n -> [tag 12, accumulateToken r, varint n]
        Match e branches -> tag 13 : hashed (hash e) : concatMap h branches
          where
            h (MatchCase pat guard branch) =
              concat [[accumulateToken pat],
                      toList (hashed . hash <$> guard),
                      [hashed (hash branch)]]
        Handle h b -> [tag 15, hashed $ hash h, hashed $ hash b]
        And x y -> [tag 16, hashed $ hash x, hashed $ hash y]
        Or x y -> [tag 17, hashed $ hash x, hashed $ hash y]

-- mostly boring serialization code below ...

instance (Eq a, Var v) => Eq1 (F v a p) where (==#) = (==)
instance (Var v) => Show1 (F v a p) where showsPrec1 = showsPrec

instance (Var vt, Eq at, Eq a) => Eq (F vt at p a) where
  Int64 x == Int64 y = x == y
  UInt64 x == UInt64 y = x == y
  Float x == Float y = x == y
  Boolean x == Boolean y = x == y
  Text x == Text y = x == y
  Blank b == Blank q = b == q
  Ref x == Ref y = x == y
  Constructor r cid == Constructor r2 cid2 = r == r2 && cid == cid2
  Request r cid == Request r2 cid2 = r == r2 && cid == cid2
  Handle h b == Handle h2 b2 = h == h2 && b == b2
  App f a == App f2 a2 = f == f2 && a == a2
  Ann e t == Ann e2 t2 = e == e2 && t == t2
  Vector v == Vector v2 = v == v2
  If a b c == If a2 b2 c2 = a == a2 && b == b2 && c == c2
  And a b == And a2 b2 = a == a2 && b == b2
  Or a b == Or a2 b2 = a == a2 && b == b2
  Lam a == Lam b = a == b
  LetRec bs body == LetRec bs2 body2 = bs == bs2 && body == body2
  Let binding body == Let binding2 body2 = binding == binding2 && body == body2
  Match scrutinee cases == Match s2 cs2 = scrutinee == s2 && cases == cs2
  _ == _ = False


instance (Var v, Show a) => Show (F v a0 p a) where
  showsPrec p fa = go p fa where
    showConstructor r n = showsPrec 0 r <> s"#" <> showsPrec 0 n
    go _ (Int64 n) = (if n >= 0 then s "+" else s "") <> showsPrec 0 n
    go _ (UInt64 n) = showsPrec 0 n
    go _ (Float n) = showsPrec 0 n
    go _ (Boolean True) = s"true"
    go _ (Boolean False) = s"false"
    go p (Ann t k) = showParen (p > 1) $ showsPrec 0 t <> s":" <> showsPrec 0 k
    go p (App f x) =
      showParen (p > 9) $ showsPrec 9 f <> s" " <> showsPrec 10 x
    go _ (Lam body) = showParen True (s"λ " <> showsPrec 0 body)
    go _ (Vector vs) = showListWith (showsPrec 0) (Vector.toList vs)
    go _ (Blank b) =
      case b of
        B.Blank -> s"_"
        B.Recorded (B.Placeholder _ r) -> s("_" ++ r)
        B.Recorded (B.Resolve _ r) -> s r
    go _ (Ref r) = showsPrec 0 r
    go _ (Let b body) = showParen True (s"let " <> showsPrec 0 b <> s" in " <> showsPrec 0 body)
    go _ (LetRec bs body) = showParen True (s"let rec" <> showsPrec 0 bs <> s" in " <> showsPrec 0 body)
    go _ (Handle b body) = showParen True (s"handle " <> showsPrec 0 b <> s " in " <> showsPrec 0 body)
    go _ (Constructor r n) = showConstructor r n
    go _ (Match scrutinee cases) =
      showParen True (s"case " <> showsPrec 0 scrutinee <> s" of " <> showsPrec 0 cases)
    go _ (Text s) = showsPrec 0 s
    go _ (Request r n) = showConstructor r n
    go p (If c t f) = showParen (p > 0) $
      s"if " <> showsPrec 0 c <> s" then " <> showsPrec 0 t <>
      s" else " <> showsPrec 0 f
    go p (And x y) = showParen (p > 0) $
      s"and " <> showsPrec 0 x <> s" " <> showsPrec 0 y
    go p (Or x y) = showParen (p > 0) $
      s"or " <> showsPrec 0 x <> s" " <> showsPrec 0 y
    (<>) = (.)
    s = showString
